// HL Risk Calculator v1.2 — 4 slots (2 long, 2 short) + autosave + autofill
(function () {
  if (document.getElementById('hl-risk-widget')) return;

  // ── STATE ──
  // slots: buy1, buy2, sell1, sell2
  const SLOTS = ['buy1','buy2','sell1','sell2'];
  let state = {
    risk: 10,
    slots: {
      buy1:  { price: '', sl: '' },
      buy2:  { price: '', sl: '' },
      sell1: { price: '', sl: '' },
      sell2: { price: '', sl: '' },
    }
  };

  // ── STORAGE ──
  function loadState(cb) {
    try {
      chrome.storage.sync.get(['hl_risk_v2'], (res) => {
        if (res && res.hl_risk_v2) state = { ...state, ...res.hl_risk_v2 };
        cb();
      });
    } catch (e) {
      try { const s = localStorage.getItem('hl_risk_v2'); if (s) state = { ...state, ...JSON.parse(s) }; } catch (_) {}
      cb();
    }
  }

  let saveTimer = null;
  function saveState() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        chrome.storage.sync.set({ hl_risk_v2: state }, () => {
          const dot = document.getElementById('hl-save-dot');
          if (dot) { dot.classList.add('active'); setTimeout(() => dot.classList.remove('active'), 700); }
        });
      } catch (e) {
        try { localStorage.setItem('hl_risk_v2', JSON.stringify(state)); } catch (_) {}
      }
    }, 350);
  }

  // ── SLOT HELPERS ──
  function slotLabel(id) {
    return { buy1: 'LONG A', buy2: 'LONG B', sell1: 'SHORT A', sell2: 'SHORT B' }[id] || id;
  }
  function slotSide(id) { return id.startsWith('buy') ? 'buy' : 'sell'; }

  // ── HTML BUILDER ──
  function slotHTML(id) {
    const s = state.slots[id] || { price: '', sl: '' };
    const isBuy  = slotSide(id) === 'buy';
    const colCls = isBuy ? 'hl-col-buy' : 'hl-col-sell';
    const arrow  = isBuy ? '▲' : '▼';
    const fillLabel = isBuy ? `▲ FILL ${slotLabel(id)}` : `▼ FILL ${slotLabel(id)}`;

    return `
      <div class="hl-col ${colCls}" data-slot="${id}">
        <div class="hl-col-title">${arrow} ${slotLabel(id)}</div>

        <div class="hl-field">
          <label>Entry Price</label>
          <div class="hl-input-wrap">
            <input type="text" id="${id}-price" placeholder="0.00" value="${s.price}" autocomplete="off" />
            <button class="hl-copy-btn" data-copy="${id}-price">copy</button>
          </div>
        </div>

        <div class="hl-field">
          <label>Stop Loss</label>
          <div class="hl-input-wrap">
            <input type="text" id="${id}-sl" placeholder="0.00" value="${s.sl}" autocomplete="off" />
            <button class="hl-copy-btn" data-copy="${id}-sl">copy</button>
          </div>
        </div>

        <div class="hl-size-result">
          <div class="hl-size-label">Position Size</div>
          <div>
            <span class="hl-size-value" id="${id}-size">—</span>
            <span class="hl-size-unit">USDC</span>
          </div>
        </div>

        <button class="hl-autofill-btn ${colCls}-fill" id="btn-autofill-${id}">
          ${fillLabel}
        </button>
      </div>
    `;
  }

  function buildWidget() {
    const wrapper = document.createElement('div');
    wrapper.id = 'hl-risk-widget';

    wrapper.innerHTML = `
      <div id="hl-widget-panel">
        <div id="hl-widget-header">
          <span id="hl-widget-title">⬡ HL RISK <span id="hl-save-dot"></span></span>
          <div id="hl-widget-controls">
            <button class="hl-ctrl-btn" id="hl-btn-minimize" title="Minimize">—</button>
            <button class="hl-ctrl-btn" id="hl-btn-close" title="Close">✕</button>
          </div>
        </div>

        <div id="hl-widget-body">

          <!-- RISK -->
          <div id="hl-risk-row">
            <label>RISK $</label>
            <input type="number" id="hl-risk-input" value="${state.risk}" min="0.1" step="0.5" />
            <div class="hl-risk-quick">
              <button class="hl-qbtn" data-risk="5">5</button>
              <button class="hl-qbtn" data-risk="10">10</button>
              <button class="hl-qbtn" data-risk="20">20</button>
              <button class="hl-qbtn" data-risk="50">50</button>
            </div>
          </div>

          <!-- SECTION HEADERS -->
          <div id="hl-section-headers">
            <div class="hl-section-label buy-label">▲ LONG</div>
            <div class="hl-section-label sell-label">▼ SHORT</div>
          </div>

          <!-- ROW 1: buy1 | sell1 -->
          <div class="hl-row">
            ${slotHTML('buy1')}
            ${slotHTML('sell1')}
          </div>

          <!-- DIVIDER -->
          <div class="hl-row-divider"></div>

          <!-- ROW 2: buy2 | sell2 -->
          <div class="hl-row">
            ${slotHTML('buy2')}
            ${slotHTML('sell2')}
          </div>

          <!-- STATUS -->
          <div id="hl-status-bar">— siap —</div>
        </div>
      </div>
    `;

    document.body.appendChild(wrapper);
    attachEvents(wrapper);
    updateAllCalc();
    updateAutofillButtons();
  }

  // ── CALC ──
  function cleanNum(val) {
    return parseFloat(String(val).replace(/,/g, '').replace(/\s/g, ''));
  }
  function roundToInt(val) { return Math.round(val); }

  function calcSize(risk, entry, sl) {
    const e = cleanNum(entry), s = cleanNum(sl);
    if (!e || !s || isNaN(e) || isNaN(s) || e === s) return null;
    return risk / (Math.abs(e - s) / e);
  }

  function formatSize(val) {
    if (val === null || isNaN(val) || !isFinite(val)) return '—';
    if (val >= 10000) return val.toFixed(0);
    if (val >= 100)   return val.toFixed(1);
    return val.toFixed(2);
  }

  function updateAllCalc() {
    const risk = parseFloat(document.getElementById('hl-risk-input')?.value) || 0;
    SLOTS.forEach(id => {
      const sl = state.slots[id];
      const size = calcSize(risk, sl.price, sl.sl);
      const el = document.getElementById(`${id}-size`);
      if (el) el.textContent = formatSize(size);
    });
  }

  // ── STATUS ──
  function setStatus(msg, type) {
    const el = document.getElementById('hl-status-bar');
    if (!el) return;
    el.textContent = msg;
    el.className = type || '';
    if (type === 'ok') setTimeout(() => { el.textContent = '— siap —'; el.className = ''; }, 3000);
  }

  function isHyperliquid() { return location.hostname.includes('hyperliquid.xyz'); }

  function updateAutofillButtons() {
    const onHL = isHyperliquid();
    SLOTS.forEach(id => {
      const btn = document.getElementById(`btn-autofill-${id}`);
      if (!btn) return;
      btn.disabled = !onHL;
      btn.title = onHL ? '' : 'Hanya berfungsi di app.hyperliquid.xyz';
    });
  }

  // ── AUTOFILL ──
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function setNativeValue(el, val) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(el, val);
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function findHLSideTab(side) {
    const allBtns = Array.from(document.querySelectorAll('button'));

    // Strategy 1: exact text match
    const exact = allBtns.find(b => {
      const t = b.textContent.trim().toLowerCase();
      if (side === 'buy')  return t === 'buy / long'   || t === 'buy/long'   || t === 'buy';
      if (side === 'sell') return t === 'sell / short'  || t === 'sell/short' || t === 'sell';
      return false;
    });
    if (exact) return exact;

    // Strategy 2: sibling pair (buy + sell in same parent)
    for (const btn of allBtns) {
      const t = btn.textContent.trim().toLowerCase();
      if (!t.includes('buy') && !t.includes('sell')) continue;
      const sibs = Array.from(btn.parentElement?.children || []);
      const texts = sibs.map(s => s.textContent.trim().toLowerCase());
      if (!texts.some(s => s.includes('buy')) || !texts.some(s => s.includes('sell'))) continue;
      if (side === 'buy'  && t.includes('buy'))  return btn;
      if (side === 'sell' && t.includes('sell')) return btn;
    }
    return null;
  }

  async function autofillHL(slotId) {
    const slot = state.slots[slotId];
    const side  = slotSide(slotId);
    const price = cleanNum(slot.price);
    const sl    = cleanNum(slot.sl);
    const risk  = parseFloat(document.getElementById('hl-risk-input').value) || 0;
    const size  = calcSize(risk, price, sl);

    if (!price || !sl || !size || isNaN(size)) {
      setStatus(`⚠ ${slotLabel(slotId)}: Isi Entry Price & SL dulu`, 'err'); return;
    }

    setStatus(`⏳ Mengisi ${slotLabel(slotId)}...`, 'warn');

    try {
      // 1. Click Buy/Sell tab
      const sideTab = findHLSideTab(side);
      if (sideTab) {
        sideTab.click();
        sideTab.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        sideTab.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true }));
        await sleep(400);
      } else {
        setStatus(`⚠ Tab ${side === 'buy' ? 'Buy/Long' : 'Sell/Short'} tidak ditemukan`, 'warn');
        await sleep(300);
      }

      // 2. Click Limit tab
      const allBtns = Array.from(document.querySelectorAll('button'));
      const limitTab = allBtns.find(b => b.textContent.trim().toLowerCase() === 'limit');
      if (limitTab) { limitTab.click(); await sleep(300); }

      // 3. Fill Price
      const allInputs = Array.from(document.querySelectorAll('input'));
      let priceInput = null;
      for (const inp of allInputs) {
        const ph  = (inp.placeholder || '').toLowerCase();
        const lbl = inp.closest('div,label')?.textContent?.toLowerCase() || '';
        if (ph.includes('price') || lbl.includes('price (usdc)') || lbl.includes('price')) {
          priceInput = inp; break;
        }
      }
      if (!priceInput) {
        const vis = allInputs.filter(i => i.type !== 'hidden' && i.offsetParent !== null);
        priceInput = vis[0] || null;
      }
      if (priceInput) {
        priceInput.focus(); priceInput.select();
        setNativeValue(priceInput, String(roundToInt(price)));
        await sleep(250);
      }

      // 4. Fill Size
      let sizeInput = null;
      const freshInputs = Array.from(document.querySelectorAll('input'));
      for (const inp of freshInputs) {
        const ph  = (inp.placeholder || '').toLowerCase();
        const lbl = inp.closest('div,label')?.textContent?.toLowerCase() || '';
        if (ph.includes('size') || lbl.includes('size')) { sizeInput = inp; break; }
      }
      if (sizeInput) {
        sizeInput.focus(); sizeInput.select();
        setNativeValue(sizeInput, String(Math.round(size)));
        await sleep(250);
      }

      // 5. Enable TP/SL checkbox
      const checks = Array.from(document.querySelectorAll('input[type="checkbox"], [role="checkbox"]'));
      for (const cb of checks) {
        const lbl = cb.closest('label,div')?.textContent?.toLowerCase() || '';
        if (lbl.includes('stop loss') || lbl.includes('tp') || lbl.includes('take profit')) {
          if (!cb.checked) { cb.click(); await sleep(350); }
          break;
        }
      }

      // 6. Fill SL
      await sleep(300);
      let slInput = null;
      for (const inp of Array.from(document.querySelectorAll('input'))) {
        const ph  = (inp.placeholder || '').toLowerCase();
        const par = inp.closest('div,label,tr')?.textContent?.toLowerCase() || '';
        if (ph.includes('sl') || ph.includes('stop') || par.includes('sl price') || par.includes('stop loss')) {
          slInput = inp; break;
        }
      }
      if (slInput) {
        slInput.focus(); slInput.select();
        setNativeValue(slInput, String(roundToInt(sl)));
        await sleep(200);
      }

      setStatus(
        `✓ ${slotLabel(slotId)}: Price=${roundToInt(price)}, Size=${Math.round(size)}, SL=${roundToInt(sl)}`,
        'ok'
      );

    } catch (err) {
      setStatus('⚠ Gagal autofill: ' + err.message, 'err');
      console.error('[HL Widget] autofill error:', err);
    }
  }

  // ── COPY BUTTON HELPER ──
  function doCopy(val, btn) {
    navigator.clipboard.writeText(val).then(() => {
      btn.textContent = '✓'; btn.classList.add('copied');
      setTimeout(() => { btn.textContent = 'copy'; btn.classList.remove('copied'); }, 1200);
    }).catch(() => {
      const ta = document.createElement('textarea');
      ta.value = val; ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
      btn.textContent = '✓'; btn.classList.add('copied');
      setTimeout(() => { btn.textContent = 'copy'; btn.classList.remove('copied'); }, 1200);
    });
  }

  // ── ATTACH EVENTS ──
  function attachEvents(wrapper) {

    // Slot inputs
    SLOTS.forEach(id => {
      ['price', 'sl'].forEach(field => {
        const el = document.getElementById(`${id}-${field}`);
        if (!el) return;
        el.addEventListener('input', () => {
          state.slots[id][field] = el.value;
          updateAllCalc(); saveState();
        });
      });
    });

    // Risk
    document.getElementById('hl-risk-input').addEventListener('input', (e) => {
      state.risk = parseFloat(e.target.value) || 0;
      updateAllCalc(); saveState();
    });

    // Quick risk
    wrapper.querySelectorAll('.hl-qbtn').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = btn.getAttribute('data-risk');
        document.getElementById('hl-risk-input').value = val;
        state.risk = parseFloat(val);
        updateAllCalc(); saveState();
      });
    });

    // Copy buttons
    wrapper.querySelectorAll('.hl-copy-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-copy');
        const input = document.getElementById(targetId);
        if (!input) return;
        const n = cleanNum(input.value);
        const isSL = targetId.includes('-sl');
        const copyVal = isNaN(n) ? input.value : (isSL ? String(roundToInt(n)) : String(n));
        doCopy(copyVal, btn);
      });
    });

    // Autofill buttons
    SLOTS.forEach(id => {
      const btn = document.getElementById(`btn-autofill-${id}`);
      if (btn) btn.addEventListener('click', () => autofillHL(id));
    });

    // Minimize
    document.getElementById('hl-btn-minimize').addEventListener('click', () => {
      const panel = document.getElementById('hl-widget-panel');
      const min = panel.classList.toggle('minimized');
      document.getElementById('hl-btn-minimize').textContent = min ? '□' : '—';
    });

    // Close
    document.getElementById('hl-btn-close').addEventListener('click', () => {
      wrapper.style.display = 'none';
      setTimeout(() => { wrapper.style.display = ''; }, 5000);
    });

    // Drag
    const header = document.getElementById('hl-widget-header');
    const panel  = document.getElementById('hl-widget-panel');
    let dragging = false, ox = 0, oy = 0;
    header.addEventListener('mousedown', (e) => {
      if (e.target.classList.contains('hl-ctrl-btn')) return;
      dragging = true; panel.classList.add('dragging');
      const r = wrapper.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      wrapper.style.right = 'auto'; wrapper.style.bottom = 'auto';
      wrapper.style.left = Math.max(0, Math.min(e.clientX - ox, window.innerWidth  - 400)) + 'px';
      wrapper.style.top  = Math.max(0, Math.min(e.clientY - oy, window.innerHeight -  60)) + 'px';
    });
    document.addEventListener('mouseup', () => { dragging = false; panel.classList.remove('dragging'); });
  }

  // ── INIT ──
  loadState(() => buildWidget());

})();
